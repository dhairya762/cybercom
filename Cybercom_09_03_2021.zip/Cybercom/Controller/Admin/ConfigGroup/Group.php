<?php

namespace Controller\Admin\ConfigGroup;



class Config extends \Controller\Core\Admin
{

    public function saveAction()
    {
        $postData = $this->getRequest()->getPost();
        $groupId = $this->getRequest()->getGet('id');
        $existConfig = $postData['exist']; 
        $newConfig = $postData['new'];

        $title = $newConfig['title'];
        $code = $newConfig['code'];
        $value = $newConfig['value'];
        $count = count($title);
        
        $newConfig = [];
        $createdDate = date('Y-m-d H:i:s');
        
        for ($i=0; $i < $count; $i++) { 
            $newConfig[$i]['title'] = $title[$i];
            $newConfig[$i]['code'] = $code[$i];
            $newConfig[$i]['value'] = $value[$i];
        }
        
        foreach ($newConfig as $key => $config) {
            $query = "INSERT INTO `config` (`groupId`, `title`, `code`, `value`) VALUES 
            ('{$groupId}', '{$config['title']}', '{$config['code']}', '{$config['value']}') ";
            $config = \Mage::getModel('Model\ConfigGroup\Config')->insert($query);
        }
        
        foreach ($existConfig as $configId => $config) {
            $title = $config['title'];
            $code = $config['code']; 
            $value = $config['value'];
            $query = "UPDATE `config` 
            SET `title`='{$title}', `code`='{$code}', `value`='{$value}'
            WHERE `configId` = '{$configId}' ";
            $option = \Mage::getModel('Model\ConfigGroup\Config')->update($query);
        }
        $this->redirect('ConfigGroup','edit',['id' => $groupId, 'tab' => 'configuration']);
    }
    
    public function deleteAction()
    {
        $groupId = $this->getRequest()->getGet('groupId');
        $configId = $this->getRequest()->getGet('configId');
        $config = \Mage::getModel('Model\ConfigGroup\Config')->delete($configId);
        $this->redirect('ConfigGroup','Edit',['id' => $groupId, 'tab' => 'configuration']);
        
    }   
}


?>