<?php

namespace Controller\Admin;

class LCM extends \Controller\Core\Admin
{
    public function gridAction()
    {
        echo "<pre>";
        $number = 1112223;
        $divisior = 1112223;
        $length = strlen((string)$number);
        $power = $length-1;
        $quotient=[];
        $reminder = [];

        for ($i=0; $i < $length; $i++) { 
            $num = intdiv($number, pow(10,$power));
            if ($num >= $divisior) {
                $rem = $num % $divisior;
                array_push($reminder, $rem);
                array_push($quotient, intdiv($num, $divisior));
                $number = $number % pow(10, $power) + ($rem*pow(10, $power));
                $power--;
            }
            else {
                array_push($reminder,$num % $divisior);
                array_push($quotient, 0);
                $power--;
            }
        }
        echo 'Quotient';
        print_r($quotient);
        echo "Reminder";
        print_r($reminder);
    }
}