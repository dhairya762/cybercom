<?php

namespace Controller\Admin;

class Configuration extends \Controller\Core\Admin
{
    public function gridAction()
    {
        $grid = \Mage::getBlock('Block\Admin\Configuration\Grid');
        $this->getLayout()->getContent()->addChild($grid);
        $this->renderLayout();
    }

    public function editAction()
    {
        $edit = \Mage::getBlock('Block\Admin\Configuration\Edit');
        $layout = $this->getLayout()->setTemplate('View/core/layout/three_column.php');
        $layout->getContent()->addChild($edit);
        $layout->getLeft()->addChild(\Mage::getBlock('Block\Admin\Configuration\Edit\Tabs'));
        $this->renderLayout();
    }
    
    public function saveAction()
    {
        try {

            $config = \Mage::getModel('Model\Configuration');
            $id = $this->getRequest()->getGet('id');
            if ($id) {
                $config = $config->load($id);
                if (!$config) {
                    throw new \Exception("Record Not Found.");
                }
            }
            $config = $config->setData($this->getRequest()->getPost('configuration'));
            if ($config->save()) {
                $this->getMessage()->setSuccess("Successfully Update/Insert");
            } else {
                $this->getMessage()->setSuccess("Unable to Update/Insert");
            }

        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid');
    }

        public function deleteAction(){
            echo "<pre>";
            try{
                $id = (int)$this->getRequest()->getGet('id');
                $configGroup = \Mage::getModel('Model\Configuration')->load($id);
                if(!$configGroup){
                    throw new \Exception("Invalid Id");
                }
                if($configGroup->delete()){
                    $this->getMessage()->setSuccess('Delete Successfully');
                }
            }catch(\Exception $e){
                $this->getMessage()->setFailure($e->getMessage());
            }
            $this->redirect('grid',null,null,true);
        }

    public function updateAction()
    {
        $ids = [];
        $configGroup = \Mage::getModel('Model\Configuration\Group');
        $configId = $this->getRequest()->getGet('id');

        $query = "SELECT `groupId` FROM `{$configGroup->getTableName()}` WHERE `configId`={$configId}";
        $groups = $configGroup->fetchAll($query);
        if ($groups) {
            foreach ($groups->getData() as $key => $value) {
                $ids[] = $value->groupId;
            }
        }
        if ($exist = $this->getRequest()->getPost('exist')) {
            foreach ($exist as $key => $value) {
                unset($ids[array_search($key, $ids)]);
                $query = "UPDATE `config_group`
                    SET `name`='{$value['name']}'
                    WHERE `groupId` = {$key}";
                $configGroup->save($query);
            }
        }
        if ($ids) {
            $query = "DELETE FROM `{$configGroup->getTableName()}` WHERE `{$configGroup->getPrimaryKey()}` IN (" . implode(",", $ids) . ")";
            $configGroup->save($query);
        }

        if ($new = $this->getRequest()->getPost('new')) {
            foreach ($new as $key => $value) {
                foreach ($value as $key2 => $value2) {
                    $newArray[$key2][$key] = $value2;
                }
            }
            foreach ($newArray as $key => $value) {
                $query = "INSERT INTO `{$configGroup->getTableName()}`(`name`, `configId`)
VALUES ('{$value['name']}',{$configId})";
                $configGroup->save($query);
            }
        }
        $this->redirect('grid', null, null, true);
    }
}
