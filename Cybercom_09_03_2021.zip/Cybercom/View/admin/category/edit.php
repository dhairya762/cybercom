<div class="container">
    <?php echo $this->getTabContent(); ?>
</div>