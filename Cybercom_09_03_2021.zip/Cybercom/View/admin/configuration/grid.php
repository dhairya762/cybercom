<?php $row = $this->getConfigurations();
$groups = $this->getGroups();
?>
<div class="container">
    <br><br><br>
    <div id="main-content">
        <h2 style="text-align: center;"><strong>Configuration Records</strong></h2>
        <a href="<?php echo $this->getUrl('edit') ?>" class="btn btn-info" role="button">Add Records</a><br><br>
            <table border="3px" cellpadding="10px" align="center" width="70%" class="table table-striped" style="border-collapse:collapse">
                <thead>
                    <th>ConfigId</th>
                    <th>GroupId</th>
                    <th>Title</th>
                    <th>Code</th>
                    <th>Value</th>
                    <th>CreatedDate</th>
                    <th colspan="2">Action</th>
                </thead>

                <tbody id="data-table" align="center">
                    <?php if (!$row) : ?>
                        <tr>
                            <td colspan="7">No Data Found!!!</td>
                        </tr>
                    <?php else : ?>
                        <?php
                        foreach ($row->getData() as $value) {
                        ?>

                            <tr>
                                <td><?php echo $value->configId; ?></td>
                                <td><?php echo $value->groupId;?></td>
                                <td><?php echo $value->title; ?></td>
                                <td><?php echo $value->code; ?></td>
                                <td><?php echo $value->value; ?></td>
                                <td><?php echo $value->createdDate; ?></td>
                                <td><a href='<?php echo $this->getUrl('edit', null, ['id' => $value->configId]) ?>' class="btn btn-Success" role="button">Update</a></td>
                                <td><a href='<?php echo $this->getUrl('delete', null, ['id' => $value->configId]) ?>' class="btn btn-danger" role="button">Delete</a></td>
                            </tr>
                    <?php }
                    endif; ?>
                </tbody>
            </table>

        </div>
    </div>

</div>