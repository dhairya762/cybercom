<?php $configuration = $this->getConfiguration();?>
<center>
<h1>Configuration Add/Update Form</h1>
<form action="<?php echo $this->getUrl('save', NULL, ['id' => $configuration->configId], true); ?>" method="POST" id='configuration'>
    <table>
        <tr>
            <td>Title:</td>
            <td><input type="text" name="configuration[title]" value="<?php echo $configuration->title; ?>"></td>
        </tr>
        <tr>
            <td>Code:</td>
            <td><input type="text" name="configuration[code]" value="<?php echo $configuration->code; ?>"></td>
        </tr>
        <tr>
            <td>Value:</td>
            <td><input type="text" name="configuration[value]" value="<?php echo $configuration->value; ?>"></td>
        </tr>
        <tr>
            <td></td>
            <td><input type="submit" value="Save"></td>
        </tr>
    </table>
</center>
</form>