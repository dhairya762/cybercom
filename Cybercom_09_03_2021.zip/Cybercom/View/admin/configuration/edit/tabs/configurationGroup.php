<?php $attribute = $this->getConfiguration();
?>
<form action="<?php echo $this->getUrl('update'); ?>" method="POST" id="option">
    <input type="submit" name="update" value="update" class="btn btn-info">
    <input type="button" name="addOption" value="Add Option" onclick="addRow();" class="btn btn-warning">
    <table id='existingOption' name='existingOption'>
        <?php if (!$attribute->getGroups()) : ?>
            <tr>
                <td colspan="3">
                    <center>No recoreds in Database.</center>
                </td>
            </tr>
        <?php else : ?>
            <?php foreach ($attribute->getGroups()->getData() as $key => $option) : ?>
                <tr>
                    <td><input type="text" name="exist[<?php echo $option->groupId; ?>][name]" value="<?php echo $option->name ?>"></td>
                    <td><input type="button" name="removeOption" value="Remove Option" onclick="removeRow(this);" class="btn btn-danger"></td>
                </tr>
                <?php endforeach;?>
        <?php endif; ?>
    </table>
</form>
    <div style="display:none">
        <table id='newOption'>
            <tbody>
                <tr>
                    <td><input type="text" name="new[name][]"></td>
                    <td><input type="submit" name="removeOption" value="Remove Option" onclick="removeRow(this)"></td>
                </tr>
            </tbody>
        </table>
    </div>

<script>
    function addRow() {
        var newOptionTable = document.getElementById('newOption');
        var existingOptionTable = document.getElementById('existingOption').children[0];
        existingOptionTable.prepend(newOptionTable.children[0].children[0].cloneNode(true));
    }

    function removeRow(button) {
        var objTr = button.parentElement.parentElement;
        objTr.remove();
        let form = document.getElementById('option');
        form.submit();
    }
</script>