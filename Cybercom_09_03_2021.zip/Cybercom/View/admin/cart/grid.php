<?php
$cart = $this->getCart();
$cartItems = $this->getCart()->getItems();
$customers = $this->getCart()->getCustomers();
$customer = $this->getCart()->getCustomer();
$discount = $cart->discount;
$customerBillingAddress = $cart->getBillingAddress();
$customerShippingAddress = $cart->getShippingAddress();
?>
<form action="<?php echo $this->getUrl('update', null, ['id' => $cart->cartId]) ?>" method="POST" id="cartForm">
    <div class="container">
        <br><br><br>
        <div id="main-content">
            <h2 style="text-align: center;"><strong>Cart</strong></h2>
            <a href="<?php echo $this->getUrl('grid', 'product') ?>" class="btn btn-primary">Back to Item</a><br><br>
            <div class="table_data">
                <table border="3px" cellpadding="10px" align="center" width="70%" class="table table-striped" style="border-collapse:collapse">
                    <thead>
                        <tr>
                            <td colspan="8">
                                <select name="customer" class="form-control">
                                    <option>Select Customer</option>
                                    <?php foreach ($customers->getData() as $key => $value) : ?>
                                        <option value="<?php echo $value->customerId; ?>" <?php if ($value->customerId == $cart->customerId) {
                                                                                                echo 'Selected';
                                                                                            } ?>><?php echo $value->firstName; ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </td>
                            <td><button type="button" class="btn btn-success" onclick="selectCustomer()">Go</button><br></td>
                        </tr>
                        <tr>
                            <th style="text-align:center">cart Id</th>
                            <th style="text-align:center">Product Id</th>
                            <th style="text-align:center">Quantity</th>
                            <th style="text-align:center">Price</th>
                            <th style="text-align:center">Row Price</th>
                            <th style="text-align:center">Discount</th>
                            <th style="text-align:center">Final Total</th>
                            <th style="text-align:center">CreatedDate</th>
                            <th style="text-align:center">Action</th>
                    </thead>
                    <tbody id="data-table" align="center">
                        <?php if (!$cartItems) : ?>
                            <tr>
                                <td colspan="9">No Data Found!!!</td>
                            </tr>
                        <?php else : ?>
                            <?php foreach ($cartItems->getData() as $key => $item) : ?>
                                <tr>
                                    <td style="text-align:center"><?php echo $item->cartId; ?></td>
                                    <td style="text-align:center"><?php echo $item->productId; ?></td>
                                    <td style="text-align:center"><input type="number" name="quantity[<?php echo $item->cartItemId; ?>]" id="quantity" value="<?php echo $item->quantity ?>"></td>
                                    <td style="text-align:center"><?php echo $item->price; ?></td>
                                    <td style="text-align:center"><?php echo $item->getRowPrice(); ?></td>
                                    <td style="text-align:center"><?php echo $item->getDiscount(); ?></td>
                                    <td style="text-align:center"><?php echo $item->getTotalPrice(); ?></td>
                                    <td style="text-align:center"><?php echo $item->createdDate; ?></td>
                                    <td style="text-align:center"><a href='<?php echo $this->getUrl('delete', null, ['id' => $item->cartItemId]) ?>' class="btn btn-danger" role="button">Delete</a></td>
                                </tr>
                            <?php endforeach; ?>
                            <a href='<?php echo $this->getUrl('clear', null, ['id' => $item->cartId]) ?>' class="btn btn-danger" role="button">Clear Cart</a>&nbsp
                            <button type="submit" class="btn btn-primary">Update</button><br><br>
                        <?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</form>
<center>
    <form action="<?php echo $this->getUrl('billingAddress');
                    ?>" method="POST">
        <h1>Order Summary</h1>
        <table style="border-collapse: separate; border-spacing: 0 50px;">
            <?php if (!$cartItems) : ?>
                <tr>
                    <td style='text-align:center'>
                        <h1>No records Found.</h1>
                    </td>
                </tr>
            <?php else : ?>
                <center>
                    <table border="1">
                        <thead>
                            <tr>
                                <th style="text-align:center" colspan="2">Product</th>
                                <th style="text-align:center">Total</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td style="text-align:center">productId</td>
                                <td style="text-align:center">quantity</td>
                                <td style="text-align:center"></td>
                            </tr>
                            <?php foreach ($cartItems->getData() as $key => $item) : ?>
                                <tr>
                                    <td style="text-align:center"><?php echo $item->productId; ?>
                                    <td style="text-align:center"><?php echo $item->quantity ?></td>
                                    <td style="text-align:center"><?php echo $item->price * $item->quantity; ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                        <tfoot>
                            <tr>
                                <th style="text-align:center" colspan="2">Subtotal</th>
                                <?php foreach ($cartItems->getData() as $key => $item) : ?>
                                    <?php static $subTotal = 0; ?>
                                    <?php
                                    $b = 0;
                                    $b = $item->price;
                                    $subTotal += $b;
                                    ?>
                                <?php endforeach; ?>
                                <td style="text-align:center">
                                    <?php echo $subTotal; ?>
                                </td>
                            </tr>
                            <tr>
                                <th style="text-align:center" colspan="2">Tax(%)</th>
                                <?php $tax = ($subTotal * 0.18); ?>
                                <td style="text-align:center"><?php echo $tax; ?></td>
                            </tr>
                            <tr>
                                <th style="text-align:center" colspan="2">Total</th>
                                <td style="text-align:center"><?php echo ($subTotal + $tax); ?></td>
                            </tr>
                        </tfoot>
                    </table>
                </center>
                <br><br>
            <?php endif; ?>
            <?php if ($cart->customerId) : ?>
                <center>
                    <table id='billing'>
                        <h1>Billing Address</h1>
                        <tr>
                            <td>
                                <input type="text" name="billing[firstName]" placeholder="First Name*" value="<?php echo $customer->firstName; ?>"><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="billing[lastName]" placeholder="Last Name*" value="<?php echo $customer->lastName; ?>"><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="email" name="billing[email]" placeholder="Email Address*" value="<?php echo $customer->email; ?>"><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="tel" name="billing[phone]" placeholder="Phone*" value="<?php echo $customer->phone; ?>"><br>
                            </td>
                        </tr>
                        <?php if ($customerBillingAddress) : ?>
                            <tr>
                                <td>
                                    <textarea cols="60" rows="3" name="billing[address]" placeholder="Address"><?php echo ($customerBillingAddress->address); ?></textarea><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="text" name="billing[country]" placeholder="Country" value="<?php echo $customerBillingAddress->country; ?>"><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="text" name="billing[city]" placeholder="City / Town*" value="<?php echo $customerBillingAddress->city ?>"><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="text" name="billing[state]" placeholder="State*" value="<?php echo $customerBillingAddress->state ?>"><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="text" name="billing[zipCode]" placeholder="Postcode / ZIP*" value="<?php echo $customerBillingAddress->zipcode ?>"><br><br>
                                </td>
                            </tr>
                        <?php else : ?>
                            <tr>
                                <td>
                                    <textarea cols="60" rows="3" name="billing[address]" placeholder="Address"></textarea><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="text" name="billing[country]" placeholder="Country"><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="text" name="billing[city]" placeholder="City / Town*"><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="text" name="billing[state]" placeholder="State*"><br>
                                </td>
                            </tr>
                            <tr>
                                <td>
                                    <input type="text" name="billing[zipCode]" placeholder="Postcode / ZIP*"><br><br>
                                </td>
                            </tr>
                        <?php endif; ?>
                        <tr>
                            <td>
                                <input type="checkbox" name="checkbox" id="chexkbox">&nbsp<strong>Shipping Address same as Billing Address.</strong>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="checkbox" name="saveAddress" id="saveAddress">&nbsp<strong>Remember My Address</strong>
                            </td>
                        </tr>
                    </table>
                </center>
                <center><button type="submit" class="btn btn-primary">Update Billing Address</button></center><br><br>
            <?php endif; ?>
    </form>
</center>

<form action="<?php echo $this->getUrl('shipmentAddress')
                ?>" method="post">
    <center>
        <?php if ($cart->customerId) :
        ?>
            <center>
                <h1>Shipping Address</h1>
                <table id="shipment">
                    <tr>
                        <td>
                            <input type="text" name="shipping[firstName]" placeholder="First Name*" value="<?php echo $customer->firstName; ?>"><br>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input type="text" name="shipping[lastName]" placeholder="Last Name*" value="<?php echo $customer->lastName; ?>"><br>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input type="email" name="shipping[email]" placeholder="Email Address*" value="<?php echo $customer->email; ?>"><br>
                        </td>
                    </tr>
                    <tr>
                        <td>
                            <input type="tel" name="shipping[phone]" placeholder="Phone*" value="<?php echo $customer->phone; ?>"><br>
                        </td>
                    </tr>
                    <?php if ($customerShippingAddress) : ?>
                        <tr>
                            <td>
                                <textarea cols="60" rows="3" name="shipping[address]" placeholder="Address"><?php echo $customerShippingAddress->address; ?></textarea><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="shipping[country]" placeholder="Country" value="<?php echo $customerShippingAddress->country; ?>"><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="shipping[city]" placeholder="City / Town*" value="<?php echo $customerShippingAddress->city ?>"><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="shipping[state]" placeholder="State*" value="<?php echo $customerShippingAddress->state ?>"><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="shipping[zipCode]" placeholder="Postcode / ZIP*" value="<?php echo $customerShippingAddress->zipcode ?>"><br><br>
                            </td>
                        </tr>
                    <?php else : ?>
                        <tr>
                            <td>
                                <textarea cols="60" rows="3" name="shipping[address]" placeholder="Address"></textarea><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="shipping[country]" placeholder="Country"><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="shipping[city]" placeholder="City / Town*"><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="shipping[state]" placeholder="State*"><br>
                            </td>
                        </tr>
                        <tr>
                            <td>
                                <input type="text" name="shipping[zipCode]" placeholder="Postcode / ZIP*"><br><br>
                            </td>
                        </tr>
                    <?php endif; ?>
                    <tr>
                        <td>
                            <input type="checkbox" name="saveAddress" id="saveAddress">&nbsp<strong>Remember My Address</strong>
                        </td>
                    </tr>
                </table>
            </center>
            <br><br>
            <center><button type="submit" class="btn btn-primary">Update Shipping Address</button></center><br><br>
        <?php endif; ?>
</form>
</center>
<form action="<?php echo $this->getUrl('payment'); ?>" method="post">

    <table id="payment">
        <h1>Payment Method</h1>
        <div class="aa-payment-method">
            <select name="payment" class="form-control">
                <option>Select Payment Method</option>
                <option value="COD" <?php if ($cart->paymentMethodId == \Model\Cart::COD) {
                                        echo 'selected';
                                    } ?>>COD</option>
                <option value="Credit Card" <?php if ($cart->paymentMethodId == \Model\Cart::CREDITCARD) {
                                                echo 'selected';
                                            } ?>>Credit Card</option>
                <option value="Debit Card" <?php if ($cart->paymentMethodId == \Model\Cart::DEBITCARD) {
                                                echo 'selected';
                                            } ?>>Debit Card</option>
                <option value="BHIM UPI" <?php if ($cart->paymentMethodId == \Model\Cart::BHIM_UPI) {
                                                echo 'selected';
                                            } ?>>BHIM UPI</option>
                <option value="Net Banking" <?php if ($cart->paymentMethodId == \Model\Cart::NET_BANKING) {
                                                echo 'selected';
                                            } ?>>Net Banking</option>
            </select><br><br>
        </div>
    </table>
    <center><button type="submit" class="btn btn-primary">Update Payment Method </button></center><br><br>
</form>
<form action="<?php echo $this->getUrl('shipment'); ?>" method="post">

    <table id="shipment">
        <h1>Shipment Service</h1>
        <div class="aa-payment-method">
            <select name="shipment" class="form-control">
                <option>Select Shipping Method</option>
                <option value="Platinum" <?php if ($cart->shippingMethodId == \Model\Cart::PLATINUM) {
                                                echo 'selected';
                                            } ?>>Platinum(1 Day)=>100$</option>
                <option value="Gold" <?php if ($cart->shippingMethodId == \Model\Cart::GOLD) {
                                            echo 'selected';
                                        } ?>>Gold(3 Day)=>50$</option>
                <option value="Silver" <?php if ($cart->shippingMethodId == \Model\Cart::SILVER) {
                                            echo 'selected';
                                        } ?>>Silver(7 Day)=>Free</option>
            </select><br><br>
        </div>
    </table>
    <center><button type="submit" class="btn btn-primary">Update Shipping Method</button></center><br><br>
</form>
<?php if ($cart->customerId) : ?>
    <table border=3 width="100%">
        <div class="aa-payment-method">
            <tr>
                <td>Final Total</td>
                <td>
                    <?php
                    echo $cart->getTotal($cartItems);
                    ?>
                </td>
            </tr>
            <tr>
                <td>Discount</td>
                <td><?php echo $cart->discount; ?></td>
            </tr>
            <tr>
                <td>Shipping Charges</td>
                <td><?php echo $cart->getShippingCharge(); ?></td>
            </tr>
            <tr>
                <td>Grand Total</td>
                <td>
                    <?php
                    echo ($cart->getTotal($cartItems) + $cart->shippingAmount - ($discount));
                    ?>
                </td>
            </tr>
        </div>
    </table>
    <a href="<?php echo $this->getUrl('grid', 'checkout'); ?>" class="btn btn-info">CheckOut</a><br><br>
<?php endif; ?>
</center>
</form>
</center>
<script type="text/javascript">
    function selectCustomer() {
        var form = document.getElementById('cartForm');
        form.setAttribute('Action', '<?php echo $this->getUrl('selectCustomer'); ?>');
        form.submit();
    }
</script>