<nav class="navbar navbar-expand-sm bg-info sticky-top"><h3>Application</h3>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;" href="http://localhost/Cybercom/index.php?c=admin&a=grid">Admin</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;" href="http://localhost/Cybercom/index.php?c=product&a=grid">Product</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;"  href="http://localhost/Cybercom/index.php?c=category&a=grid">Category</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;"  href="http://localhost/Cybercom/index.php?c=customer&a=grid">Customer</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;"  href="http://localhost/Cybercom/index.php?c=customergroup&a=grid">Customer Group</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;"  href="http://localhost/Cybercom/index.php?c=shipment&a=grid">Shipment Method</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;" href="http://localhost/Cybercom/index.php?c=payment&a=grid">Payment Method</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;" href="http://localhost/Cybercom/index.php?c=attribute&a=grid">Attribute</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;" href="http://localhost/Cybercom/index.php?c=cmsPage&a=grid">Cms Page</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;" href="http://localhost/Cybercom/index.php?c=Cart&a=grid">Cart</a>
    <a class="nav-link text-white font-weight-bold" style="width: 8rem;" href="http://localhost/Cybercom/index.php?c=Configuration&a=grid">Configuration</a>
</nav>