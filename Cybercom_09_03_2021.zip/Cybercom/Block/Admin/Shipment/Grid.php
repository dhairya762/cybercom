<?php
namespace Block\Admin\Shipment;

class Grid extends \Block\Core\Template
{
    protected $shipments = [];

    public function __construct() {
        $this->setTemplate('./View/admin/shipment/grid.php');
    }

    public function setShipments($shipments = NULL) {
        if(!$shipments) {
            $shipments = \Mage::getModel('Model\Shipment');
            $shipments = $shipments->fetchAll();
           
        }
        $this->shipments = $shipments;
        //print_r($shipments); die();
        return $this;
    }

    public function getShipments() 
    {
        if (!$this->shipments) {
            $this->setShipments();
        }
        return $this->shipments;
    }
    
}
?>
