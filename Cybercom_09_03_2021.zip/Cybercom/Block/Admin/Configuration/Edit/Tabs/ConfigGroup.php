<?php
namespace Block\Admin\Configuration\Edit\Tabs;

class ConfigGroup extends \Block\Core\Template{
    protected $configure = null;

    public function __construct(){
        $this->setTemplate('View/admin/configuration/edit/tabs/configurationGroup.php');
    }
    
    public function setConfiguration($configure = null){
        if(!$configure){
            $configure = \Mage::getModel('Model\Configuration');
            $id = $this->getRequest()->getGet('id');
            $configure = $configure->load($id);
        }
        $this->configure = $configure;
        return $this;
    }
    public function getConfiguration(){
        if(!$this->configure){
            $this->setConfiguration();
        }
        return $this->configure;
    }
}


?>