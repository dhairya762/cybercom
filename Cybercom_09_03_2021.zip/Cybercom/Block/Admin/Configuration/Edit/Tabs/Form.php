<?php

namespace Block\Admin\Configuration\Edit\Tabs;

class Form extends \Block\Core\Template
{

    protected $configuration = null;

    function __construct()
    {
        $this->setTemplate('View/admin/configuration/edit/tabs/form.php');
    }

    public function setConfiguration($configuration = null)
    {
        if ($configuration) {
            $this->configuration = $configuration;
            return $this;
        }
        $configuration = \Mage::getModel('Model\Configuration');

        if ($id = $this->getRequest()->getGet("id")) {

            $configuration = $configuration->load($id);
        }
        $this->configuration = $configuration;
        return $this;
    }
    public function getConfiguration()
    {
        if (!$this->configuration) {
            $this->setConfiguration();
        }
        return $this->configuration;
    }
}
