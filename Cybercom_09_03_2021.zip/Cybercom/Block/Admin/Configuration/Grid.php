<?php

namespace Block\Admin\Configuration;
class Grid extends \Block\Core\Template
{
    protected $configurations = [];
    protected $groups = [];

    public function __construct()
    {
        $this->setTemplate('View/admin/configuration/grid.php');
    }

    public function setConfigurations($configurations = null)
    {
        if (!$configurations) {
            $configurations = \Mage::getModel('Model\Configuration')->fetchAll();
        }
        $this->configurations = $configurations;

        return $this;
    }
    public function getConfigurations()
    {
        if (!$this->configurations) {
            $this->setConfigurations();
        }
        return $this->configurations;
    }

    public function getGroupData()
    {
        return \Mage::getModel('Model\Configuration\Group')->fetchAll();
    }

    public function setGroups(\Model\Configuration\Group\Collection $groups)
    {
        $this->groups = $groups;
        return $this;
    }

    public function getGroups()
    {
        $groups = \Mage::getModel('Model\Configuration\Group')->fetchAll();
        $this->setGroups($groups);
        return $this->groups;
    }


}
