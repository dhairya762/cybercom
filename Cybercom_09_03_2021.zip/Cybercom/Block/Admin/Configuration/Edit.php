<?php

namespace Block\Admin\Configuration;
class Edit extends \Block\Core\Template
{

    protected $configuration = null;

    function __construct()
    {
        $this->setTemplate('View/admin/configuration/edit.php');
    }

    public function getTabContent()
    {
        $tabBlock = \Mage::getBlock('Block\Admin\Configuration\Edit\Tabs');
        $tabs = $tabBlock->getTabs();
        $tab = $this->getRequest()->getGet('tabs', $tabBlock->getDefaultTab());
        if (!array_key_exists($tab, $tabs)) {
            return null;
        }
        $blockClassName = $tabs[$tab]['block'];
        $block = \Mage::getBlock($blockClassName);
        echo $block->toHtml();
    }

    public function setConfiguration($configuration = NULL)
    {
        if ($configuration) {
            $this->configuration = $configuration;
            return $this;
        }
        $configuration = \Mage::getModel('Model\Configuration');

        if ($id = $this->getRequest()->getGet('configId')) {
            $configuration = $configuration->load($id);
        }
        $this->configuration = $configuration;
        return $this;
    }
    public function getConfiguration()
    {
        if (!$this->configuration) {
            $this->setConfiguration();
        }
        return $this->configuration;
    }
}
