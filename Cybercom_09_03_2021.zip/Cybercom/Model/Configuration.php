<?php

namespace Model;
class Configuration extends \Model\Core\Table 
{
    public function __construct()
    {
        $this->setTableName('config');
        $this->setPrimaryKey('configId');
    }

    public function getGroups()
    {
        $configGroup = \Mage::getModel('Model\Configuration\Group');
        if (!$this->configId) {
            return false;
        }
        $query = "SELECT * FROM `{$configGroup->getTableName()}`
        WHERE `configId` = '{$this->configId}'";
        return $configGroup->fetchAll($query);
    }

    
}

?>