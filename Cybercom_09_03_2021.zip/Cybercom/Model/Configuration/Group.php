<?php
namespace Model\Configuration;

class Group extends \Model\Core\Table 
{
    public function __construct()
    {
        $this->setTableName('config_group');
        $this->setPrimaryKey('groupId');
    }

    public function getConfigId($configId)
    {
        echo $query = "SELECT `groupId` FROM `config_` WHERE `configId` = '{$configId}'";
        $config = \Mage::getModel('Model\Configuration')->fetchRow($query);
        echo "<pre>";
        // $config_group = \Mage::getModel('Model\Configuration\Group');
        // $query = "SELECT * FROM `{$config_group->getTableName()}`
        // WHERE `groupId` = '{$configId}'";
        // $group = $config_group->fetchRow($query);
        return $config->groupId;
        // die;
        // return $group->groupId;
    }
}

?>