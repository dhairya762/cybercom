<?php

namespace Model;

class Cart extends \Model\Core\Table
{
    const PLATINUM = 1;
    const GOLD = 2;
    const SILVER = 3;
    const PLATINUM_FEE = 100;
    const GOLD_FEE = 50;
    const SILVER_FEE = 0;
    const COD = 1;
    const BHIM_UPI = 2;
    const CREDITCARD = 3;
    const DEBITCARD = 4;
    const NET_BANKING = 5;

    protected $customer = null;
    protected $customers = null;
    protected $items = null;
    protected $billingAddress = null;
    protected $shippingingAddress = null;
    protected $payment = null;
    protected $shipment = null;
    public function __construct()
    {
        $this->setTableName('cart');
        $this->setPrimaryKey('cartId');
    }

    public function setCustomer(\Model\Customer $customer)
    {
        $this->customer = $customer;
        return $this;
    }

    public function getCustomer()
    {
        if ($this->customer) {
            return $this->customer;
        }
        if (!$this->customerId) {
            return false;
        }
        $customer = \Mage::getModel('Model\Customer')->load($this->customerId);
        $this->setCustomer($customer);
        return $this->customer;
    }

    public function setItems(\Model\Cart\Item\Collection $items)
    {
        $this->items = $items;
        return $this;
    }

    public function getItems()
    {
        if (!$this->cartId) {
            return false;
        }
        $query = "SELECT * FROM `cartItem` WHERE `cartId` = '{$this->cartId}'";
        $items = \Mage::getModel('Model\Cart\Item')->fetchAll($query);
        if (!$items) {
            return false;
        }
        $this->setItems($items);
        return $this->items;
    }

    public function setCustomers(\Model\Customer\Collection $customers)
    {
        $this->customers = $customers;
        return $this;
    }

    public function getCustomers()
    {
        $customers = \Mage::getModel('Model\Customer')->fetchAll();
        $this->setCustomers($customers);
        return $this->customers;
    }


    public function addItemToCart($product, $quantity = 1, $addMode = false)
    {
        $cartItem = \Mage::getModel('Model\Cart\Item');
        $query = "SELECT * FROM `{$cartItem->getTableName()}` WHERE `cartId` = '{$this->cartId}' AND `productId` = '{$product->productId}'";
        $cartItem = $cartItem->fetchRow($query);

        if ($cartItem) {
            $cartItem->quantity += $quantity;
            $cartItem->save();
            return true;
        }
        $cartItem = \Mage::getModel('Model\Cart\Item');
        $cartItem->cartId = $this->cartId;
        $cartItem->productId = $product->productId;
        $cartItem->price = $product->price;
        $cartItem->quantity = $product->quantity;
        $cartItem->discount = $product->discount;
        $cartItem->save();
        return true;
    }

    public function setBillingAddress($address)
    {
        $this->billingAddress = $address;
        return $this;
    }

    public function getBillingAddress()
    {
        $cartAddress = \Mage::getModel('Model\Cart\Address')->getCartBillingAddress($this->cartId);
        if ($cartAddress) {
            $this->setBillingAddress($cartAddress);
            return $this->billingAddress;
        }
        $customerBillingAddress = $this->getCustomer()->getCustomerBillingAddress();
        if ($customerBillingAddress) {
            $this->setBillingAddress($customerBillingAddress);
            return $this->billingAddress;
        }
        return null;
        /*
        if  cart billingAddress == 1
        {
            setBillingAddress($billingAddress);
            return this->cartAddress
        }
        $customerBillingAddress = $this->getCustomer()->getBillingAddress();
        if($customerBillingAddress)
        {
            setBillingAddress($customerBillingAddress);
            return this->cartAddress
        }
        return null
        */
    }

    public function setShippingAddress($address)
    {
        $this->shippingAddress = $address;
        return $this;
    }

    public function getShippingAddress()
    {
        $cartAddress = \Mage::getModel('Model\Cart\Address')->getCartShippingAddress($this->cartId);
        if ($cartAddress) {
            $this->setShippingAddress($cartAddress);
            return $this->shippingAddress;
        }
        $customerShippingAddress = $this->getCustomer()->getCustomerShippingAddress();
        if ($customerShippingAddress) {
            $this->setShippingAddress($customerShippingAddress);
            return $this->shippingAddress;
        }
        return null;
    }

    public function getShippingCharge()
    {
        $query = "SELECT `shippingAmount` FROM `{$this->getTableName()}` WHERE customerId = '$this->customerId'";
        $shippingAmount = $this->fetchRow($query)->shippingAmount;
        return $shippingAmount;
    }

    public function getTotal($items)
    {
        $price = 0;
        if ($items) {
            foreach ($items->getData() as $key => $item) {
                $price += ($item->price - $item->discount) * $item->quantity;
            }
        }
        return $price;
    }
}
