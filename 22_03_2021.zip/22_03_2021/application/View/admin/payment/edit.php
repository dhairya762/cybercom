<?php //require_once "header.php"; ?>

<div class="container">
    <h2 style="text-align:center ;">Payment Add/Update Form</h2>

        <form method="post" action="<?php echo $this->getUrl('save') ?>">
        <?php echo $this->getTabContent(); ?>

        </form>
</div>
?>