<?php
namespace Block\Core\Edit;

interface EditInterface{
    public function getFormUrl();
    
} 

?>