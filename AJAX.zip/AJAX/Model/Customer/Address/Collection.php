<?php

namespace Model\Customer\Address;

class Collection extends \Model\Core\Table\Collection
{
}
