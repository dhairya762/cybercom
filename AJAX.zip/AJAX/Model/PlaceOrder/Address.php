<?php 

namespace Model\PlaceOrder;
class Address extends \Model\Core\Table{
    public function __construct(){
        parent::__construct();
        $this->setTableName("placeorderaddress");
        $this->setPrimaryKey("placeOrderAddressId");
    }
}

?>