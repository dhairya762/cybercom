<?php

namespace Block\Core\Layout;

class Left extends \Block\Core\Template{
    public function __construct(){
        $this->setTemplate('./View/core/layout/left.php');
    }
}

?>