<?php
namespace Block\Admin\CustomerGroup;
class Edit extends \Block\Core\Edit{
    
    public function __construct(){
        parent::__construct();
    }
}
?>