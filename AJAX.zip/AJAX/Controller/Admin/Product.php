<?php

namespace Controller\Admin;
class Product extends \Controller\Core\Admin
{
    public function gridAction(){
        try{
            $grid = \Mage::getBlock('Block\Admin\Product\Grid')->toHtml();
            $this->makeResponse($grid);
        }catch(\Exception $e){
            $e->getMessage();
        }
    }
    public function saveAction(){
        try{
            $product = \Mage::getModel('Model\Product');
            $id = $this->getRequest()->getGet('productId');
            if($id){
                $product = $product->load($id);
                if(!$product){
                    throw new \Exception("Record Not Found.");
                }
            }
            $product = $product->setData($this->getRequest()->getPost('product'));
            if($product->save()){
                if ($id) {
                    $this->getMessage()->setSuccess("Successfully Updated");
                }
                $this->getMessage()->setSuccess('Successfully Inserted');
            }else{
                if ($id) {
                    $this->getMessage()->setSuccess("Unable to Update");
                }
                $this->getMessage()->setSuccess("Unable to Insert");
            }

            $grid = \Mage::getBlock('Block\Admin\Product\Grid')->toHtml();
            $this->makeResponse($grid);
        }catch(\Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
    }

    public function deleteAction(){
        try{
            $id = $this->getRequest()->getGet('productId');
            $product = \Mage::getModel("Model\Product");
            $product->load($id);
            if($id != $product->productId){
                throw new \Exception('Id is Invalid');
            }
            if($product->delete()){
                $this->getMessage()->setSuccess("Delete Successfully");
            }
        }catch(\Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
        $grid = \Mage::getBlock('Block\Admin\Product\Grid')->toHtml();
        $this->makeResponse($grid);
    }

    public function editFormAction(){
        try{
            $product = \Mage::getModel('Model\Product');
            $id = (int)$this->getrequest()->getGet('productId');
            if($id){
                $product = $product->load($id);
                if(!$product){
                    throw new \Exception('No Record Found!!');
                }
            }

            $leftBlock = \Mage::getBlock('Block\Admin\Product\Edit\Tabs');
            $editBlock = \Mage::getBlock('Block\Admin\Product\Edit');
            $editBlock = $editBlock->setTab($leftBlock)->setTableRow($product)->toHtml();
            $this->makeResponse($editBlock);
        }catch(\Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
        }
   }

    public function addImageAction(){
        $media = \Mage::getModel('Model\Product\Media');
        // $media->setTableName('product_media');
        // $Pid = $media->getPrimaryKey();
        $id = $this->getRequest()->getGet('productId');
        $name = $_FILES['image']['name'];
        // $extension = strtolower(substr($name, strpos($name,'.')+1));
        // $type = $_FILES['image']['type'];
        $tmp_name = $_FILES['image']['tmp_name'];
        $location = 'Upload/';

            if(move_uploaded_file($tmp_name,$location.$name)){
                $media->image = $location.$name;
                $media->label = $name;
                $media->productId = $id;
                $data = $media->getData();
                $query = "INSERT INTO `{$media->getTableName()}` (".implode(",", array_keys($data)) . ") VALUES ('" . implode("','", array_values($data)) . "')"; 
                $media->save($query);
            }

        $product = \Mage::getModel('Model\Product');
        $leftBlock = \Mage::getBlock('Block\Admin\Product\Edit\Tabs');
        $editBlock = \Mage::getBlock('Block\Admin\Product\Edit');
        $editBlock = $editBlock->setTab($leftBlock)->setTableRow($product)->toHtml();
        $this->makeResponse($editBlock);
    }

    public function removeImageAction(){
        $media = \Mage::getModel('Model\Product\Media');
        $id = $this->getRequest()->getGet('productId');
        if (!$id) {
            throw new \Exception("Product(ProductId) is not available");
        }
        $ids = $this->getRequest()->getPost('delete');
        
        if($ids){
            foreach($ids as $key=>$value){
                $media->load($key);
                if(unlink($media->image)){
                    $media->delete();
                }
            }
        }
        
        $leftBlock = \Mage::getBlock('Block\Admin\Product\Edit\Tabs');
        $editBlock = \Mage::getBlock('Block\Admin\Product\Edit');
        $editBlock = $editBlock->setTab($leftBlock)->setTableRow($media)->toHtml();
        $this->makeResponse($editBlock);
    }
    public function updateMediaAction(){
        $media = \Mage::getModel('Model\Product\Media');
        $id = $this->getRequest()->getGet('productId');
        if (!$id) {
            throw new \Exception("Product(ProductId) is not available");
        }
        $data = $this->getRequest()->getPost();
        $radio['small'] = $data['small'];
        $radio['thumb'] = $data['thumb'];
        $radio['base'] = $data['base'];
        foreach($data['label'] as $key=>$value){
            $query = "UPDATE `{$media->getTableName()}` SET `label` = '{$data['label'][$key]}',";
            foreach($radio as $key2=>$value2){
                if($value2 == $key){
                    $query .= "`{$key2}` = 1,";
                }else{
                    $query .= "`{$key2}` = 0,";
                }
            }

            $query .= "`gallery` = ";
            if(array_key_exists('gallery',$data) && array_key_exists($key,$data['gallery'])){
                $query .= "1";
            }else{
                $query .= "0";
            }
            $query .= " WHERE `{$media->getPrimaryKey()}` = {$key}";
            $media->save($query);
        }
        $leftBlock = \Mage::getBlock('Block\Admin\Product\Edit\Tabs');
        $editBlock = \Mage::getBlock('Block\Admin\Product\Edit');
        $editBlock = $editBlock->setTab($leftBlock)->setTableRow($media)->toHtml();
        // $grid = \Mage::getBlock('Block\Admin\Product\Grid')->toHtml();
        $this->makeResponse($editBlock);
    }
    
    public function groupPriceAction(){
        $product = \Mage::getModel('Model\Product');
        $id = $this->getRequest()->getPost('productId');
        $productGroup = \Mage::getModel('Model\Product\Group\Price');
        $data = $this->getRequest()->getPost();
        if(array_key_exists('old',$data['price'])){
            $old = $data['price']['old'];
            foreach($old as $key=>$value){
                $query = "UPDATE `{$productGroup->getTableName()}` 
                    SET `groupPrice`='{$value}' 
                    WHERE `{$product->getPrimaryKey()}` = '{$id}' && `customerGroupId`='{$key}'";
                $productGroup->save($query);
            }
        }
        if(array_key_exists('new',$data['price'])){
            $new = $data['price']['new'];
            foreach($new as $key=>$value){
                if(!$value){ continue; }
                $query = "INSERT INTO `{$productGroup->getTableName()}` (`{$product->getPrimaryKey()}`, `customerGroupId`, `groupPrice`)
                    VALUES({$id}, {$key}, '{$value}')";
                $product->save($query);
            }
        }
        $grid = \Mage::getBlock('Block\Admin\Product\Grid')->toHtml();
        $this->makeResponse($grid);
    }

    public function filterAction(){
        $this->getFilter()->setFilters($this->getRequest()->getPost('field'));
        $grid = \Mage::getBlock('Block\Admin\Product\Grid')->toHtml();
        $this->makeResponse($grid);
    }

}

?>