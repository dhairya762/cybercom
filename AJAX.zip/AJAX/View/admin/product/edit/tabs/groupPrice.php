<?php $groupPrice = $this->getGroupPrice(); ?>

<h1>Group Price</h1>
<center>
<form id="form" action="<?php echo $this->getUrl()->getUrl('groupPrice',null,[],true) ?>" method="POST">
    <input type="button" onclick="mage.setForm()" name="save" value="UPDATE">
    <table class="grid">
        <tr class="gridtr">
            <th style="text-align:center" class="gridth">Group Id</th>
            <th style="text-align:center" class="gridth">Group Name</th>
            <th style="text-align:center" class="gridth">Group Price</th>
            <th cstyle="text-align:center" lass="gridth">Version</th>
        </tr>
        <?php if(!$groupPrice):?>
        <tr>
        <td colspan = '4'><center>No data available.</center></td>
        </tr>
        <?php else:?>
        <?php foreach($groupPrice as $key=>$value): ?>
        <?php $type = ($value->groupPriceId) ? "old" : "new" ; ?>
            <tr class="gridtr">
                <td style="text-align:center" class="gridtd" ><?php echo $value->groupId ?></td>
                <td style="text-align:center" class="gridtd"><?php echo $value->groupName ?></td>
                <td style="text-align:center" class="gridtd" ><input type = "text" name="price[<?php echo $type; ?>][<?php echo $value->groupId ?>]" value="<?php echo $value->groupPrice ?>"></td>
                <td style="text-align:center" class="gridtd"><?php echo $type;?></td> 
            </tr>
        <?php endforeach;?>
        <?php endif;?>
    </table>
</form>
</center>