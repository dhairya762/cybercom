<center>
    <table width='100%' height='100%'>
        <tbody>
            <tr class="gridtr">
                <td class="gridtd"><?php echo $this->getTabHtml(); ?></td>
                <td class="gridtd"><?php echo $this->getTabContent(); ?></td>
            </tr>
        </tbody>
    </table>
</center>