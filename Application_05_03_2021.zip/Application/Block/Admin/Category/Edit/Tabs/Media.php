<?php
namespace Block\Admin\Category\Edit\Tabs;

class Media extends \Block\Core\Template
{
    function __construct()
    {   
       $this->setTemplate('./View/admin/category/edit/tabs/media.php'); 
    }
    
}

?>