<?php
namespace Block\Admin\Admin;

class Edit extends \Block\Core\Template
{
    protected $admin = NULL;

    public function __construct() {
        $this->setTemplate('./View/admin/admin/edit.php');
    }

    public function setAdmin($admin = NULL){
        if (!$admin){
            $admin = \Mage::getModel('Model\Admin');
            if($id = $this->getRequest()->getGet('id')){
                $admin = $admin->load($id);
            }
        }
        $this->admin = $admin;
        return $this;
    }
    
    public function getAdmin(){
        if (!$this->admin){
            $this->setAdmin();
        }
        return $this->admin;
    }

    
}



?>