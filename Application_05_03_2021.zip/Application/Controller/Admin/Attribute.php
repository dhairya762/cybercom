<?php

namespace Controller\Admin;

\Mage::loadFileByClassName('Controller\Core\Admin');

class Attribute extends \Controller\Core\Admin
{

    public function gridAction()
    {
        $grid = \Mage::getBlock('Block\Admin\Attribute\Grid');

        $layout = $this->getLayout();
        $layout->getContent()->addChild($grid);
        echo $layout->toHtml();
    }

    public function editAction()
    {
        $edit = \Mage::getBlock('Block\Admin\Attribute\Edit');

        $layout = $this->getLayout()->setTemplate('View/core/layout/three_column.php');
        $layout->getContent()->addChild($edit);
        $layout->getLeft()->addChild(\Mage::getBlock('Block\Admin\Attribute\Edit\Tabs'));
        echo $layout->toHtml();
    }

    public function saveAction()
    {
        $attribute = \Mage::getModel('Model\Attribute');
        $data = $this->getRequest()->getPost('attribute');
        if ($id = $this->getRequest()->getGet('id')) {
            echo 2;
            $attribute->load($id)->getData($data);
            $attribute->attributeId = $id;
        }
        $attribute->setData($data);
        $attribute->save();
        $this->redirect('grid', null, null, true);
    }

    public function optionAction()
    {
        $option = \Mage::getModel('Model\Attribute\Option');
        if ($id = $this->getRequest()->getGet('optionId')) {
            $option->load($id);
        }
        $optionBlock = \Mage::getBlock('Block\Admin\Attribute\Edit\Tabs\Option');
        $optionBlock->setAttribute($option);
        $layout = $this->getLayout();
        $layout->getContent()->addChild($optionBlock);
        echo $layout->toHtml();
    }

    public function updateAction()
    {
        $attribute = \Mage::getModel('Model\Attribute\Option');
        $attributeId = $this->getRequest()->getGet('id');

        echo $query = "SELECT `optionId` FROM `attribute_option` WHERE `attributeId`={$attributeId}";
        foreach ($attribute->fetchAll($query)->getData() as $key => $value) {
            $ids[] = $value->optionId;
        }

        if ($exist = $this->getRequest()->getPost('exist')) {
            foreach ($exist as $key => $value) {
                unset($ids[array_search($key, $ids)]);
                $query = "UPDATE `attribute_option`
                        SET `name`='{$value['name']}',`attributeId`={$attributeId},`sortOrder`={$value['sortOrder']}
                        WHERE `optionId` = {$key}";
                $attribute->save($query);
            }
        }

        if ($ids) {
            $query = "DELETE FROM `attribute_option` WHERE `optionId` IN (" . implode(",", $ids) . ")";
            $attribute->save($query);
        }

        if ($new = $this->getRequest()->getPost('new')) {
            foreach ($new as $key => $value) {
                foreach ($value as $key2 => $value2) {
                    $newArray[$key2][$key] = $value2;
                }
            }
            foreach ($newArray as $key => $value) {
                echo $query = "INSERT INTO `attribute_option`(`name`, `attributeId`, `sortOrder`)
                        VALUES ('{$value['name']}',{$attributeId},{$value['sortOrder']})";
                die;
                $attribute->save($query);
            }
        }
        $this->redirect('grid', null, null, true);
    }

    public function deleteAction()
    {
        $id = $this->getRequest()->getGet('id');

        $attribute = \Mage::getBlock("Model\Attribute");
        $attribute->load($id);

        if ($id != $attribute->attributeId) {
            throw new \Exception('Id is Invalid');
        }
        $attribute->delete();
        $this->redirect('grid', null, null, true);
    }
}
