<?php

namespace Controller\Admin;


class Product extends \Controller\Core\Admin
{
    public function gridAction()
    {
        try {
            $gridBlock = \Mage::getBlock("Block\Admin\Product\Grid");
            $layout = $this->getLayout();

            $content = $layout->getChild('content');
            $content->addChild($gridBlock);
            $layout->setTemplate("View/core/layout/one_column.php");
            $this->renderLayout();

            // $this->getMessage()->getSuccess();
            // $message->clearSuccess();
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
    }
    public function saveAction()
    {

        try {
            $product = \Mage::getModel('Model\Product');

            if (!$this->getRequest()->isPost()) {
                throw new \Exception("Invalid Request");
            }
            if ($id = $this->getRequest()->getGet('id')) {
                $product = $product->load($id);
                if (!$product) {
                    throw new \Exception("Records not found.");
                }
            }
            $productData = $this->getRequest()->getPost('product');
            $product->setData($productData);
            $product->save();
            if ($this->getRequest()->getGet('id')) {
                $this->getMessage()->setSuccess('Record Successfully Edited.');    
            }
            else {
                $this->getMessage()->setSuccess('Record Inserted Successfully.');    
            }
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect("grid");
    }
    
    public function productDeleteAction()
    {
        try {
            $id = $this->getRequest()->getGet('id');

            $product = \Mage::getModel("Model\Product");
            $product->load($id);
            if ($id != $product->productId) {
                throw new \Exception('Id is Invalid');
            }
            if ($product->delete()) {
                $this->getMessage()->setSuccess("Delete Successfully");
            }
            else
            {
                $this->getMessage()->setFailure("Unable to delete records");
            }

            $this->redirect('grid');
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
    }
    public function formAction()
    {
        try {
            $formBlock = \Mage::getBlock("Block\Admin\Product\Edit");

            $layout = $this->getLayout();

            $content = $layout->getChild('content');
            $content->addChild($formBlock);
            $layout->setTemplate("View/core/layout/three_column.php");

            $left = $layout->getChild('left');
            $leftContent = \Mage::getBlock('Block\Admin\Product\Edit\Tabs');
            $left->addChild($leftContent);

            echo $layout->toHtml();
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
            $this->redirect('grid');
        }
    }
    public function productUpdateAction()
    {
        try {
            $gridBlock = \Mage::getBlock('Block\Admin\Product\Edit');
            $gridBlock->setController($this);
            $layout = $this->getLayout();
            $layout->getLeft()->addChild(\Mage::getBlock('Block\Admin\Product\Edit\Tabs'));
            $layout->setTemplate('./View/core/layout/three_column.php');
            $content = $layout->getChild('content');
            $content->addChild($gridBlock);
            $this->renderLayout();
        } catch (\Exception $e) {
            echo $e->getMessage();
        }
    }
}
