<?php

namespace Controller\Admin;

class Cart extends \Controller\Core\Admin
{
    public function addToCartAction()
    {
        try {
            $customerId = $this->getCart()->customerId;
            if (!$customerId) {
                $this->getMessage()->setFailure('Select customer brfore adding items into cart.');
                $this->redirect('grid');
            }
            $cart = $this->getCart();
            $productId = (int) $this->getRequest()->getGet('id');
            $product = \Mage::getModel('Model\Product')->load($productId);

            if (!$product) {
                throw new \Exception("Product is not valid.");
            }
            $cart->addItemToCart($product, $quantity = 1, 'true');
            $this->getMessage()->setSuccess("Item added into cart");
            $this->redirect('grid');
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
    }

    public function getCart($customerId = null)
    {
        $session = \Mage::getModel('Model\Admin\Session');
        if ($customerId) {
            $session->customerId = $customerId;
        }
        // $sessionId = \Mage::getModel('Model\Admin\Session')->getId();
        $cart = \Mage::getModel('Model\Cart');
        $query = "SELECT * FROM `{$cart->getTableName()}` WHERE `customerId` = '{$session->customerId}'";
        $cart = $cart->fetchRow($query);
        if ($cart) {
            return $cart;
        }
        $cart = \Mage::getModel('Model\Cart');
        $cart->customerId = $session->customerId;
        $cart->save();
        return $cart;
    }

    public function gridAction()
    {
        $cart = $this->getCart();
        $grid = \Mage::getBlock('Block\Admin\Cart\Grid')->setCart($cart);
        $layout = $this->getLayout();
        $layout->getContent()->addChild($grid);
        $this->renderLayout();
    }
    public function deleteAction()
    {
        $id = $this->getRequest()->getGet('id');
        $cartItem = \Mage::getModel("Model\Cart\Item")->load($id);
        $cartItem->delete();
        $this->redirect('grid', null, null, true);
    }

    public function clearAction()
    {
        $cartItem = \Mage::getModel('Model\Cart\Item');
        $query = "DELETE FROM `{$cartItem->getTableName()}`";
        $cartItem->delete($query);
        $this->redirect('grid');
    }

    public function updateAction()
    {
        try {
            $quantities = $this->getRequest()->getPost('quantity');
            if ($quantities) {

                foreach ($quantities as $cartItemId => $quantity) {
                    $cartItem = \Mage::getModel('Model\Cart\Item')->load($cartItemId);
                    $cartItem->quantity = $quantity;
                    if ($cartItem->quantity < 0) {
                        throw new \Exception('Invalid input in quantity.');
                    }
                    if ($cartItem->quantity == 0) {
                        $query = "DELETE FROM `cartitem` WHERE `cartItemId` = $cartItemId AND `productId` = '{$cartItem->productId}'";
                        $cartItem->delete($query);
                    }
                    $cartItem->save();
                }
                $this->getMessage()->setSuccess("Quantity successfully updated.");
            }
        } catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }
        $this->redirect('grid');
    }

    public function selectCustomerAction()
    {
        $customerId = $this->getRequest()->getPost('customer');
        $this->getCart($customerId);
        $this->redirect('grid');
    }

    public function billingAddressAction()
    {
        $checkbox = $this->getRequest()->getPost('checkbox');
        $customerBillingAddress = $this->getCart()->getCustomer()->getCustomerBillingAddress();
        $address = \Model\Customer\Address::ADDRESS_TYPE_BILLING;
        $cartId = $this->getCart()->cartId;
        $customerId = $this->getCart()->customerId;
        $billingAddress = $this->getRequest()->getPost('billing');
        $saveAddress = $this->getRequest()->getPost('saveAddress');
        $cartAddress = \Mage::getModel('Model\Cart\Address');
        $customerAddress = \Mage::getModel('Model\Customer\Address');

        if ($checkbox) {
            $address = \Model\Customer\Address::ADDRESS_TYPE_SHIPPING;
            $shippingAddress = $billingAddress;
            $query = "UPDATE `cartaddress` SET `city`='{$shippingAddress['city']}',`state`='{$shippingAddress['state']}',`country`='{$shippingAddress['country']}',`zipCode`={$shippingAddress['zipCode']} WHERE `cartId`={$cartId}";
            $cartAddress->save($query);
            $query = "UPDATE `customer_address` SET `address`='{$shippingAddress['address']}',`city`='{$shippingAddress['city']}',`state`='{$shippingAddress['state']}',`zipcode`='{$shippingAddress['zipCode']}',`country`='{$shippingAddress['country']}' WHERE `customerId` = '{$customerId}' AND `addressType`='{$address}'";
            $customerAddress->save($query);
        }
        if (!$customerBillingAddress) {
            $query = "INSERT INTO `cartaddress`(`cartId`,`addressType`, `address`, `city`, `state`, `country`, `zipCode`) VALUES ('{$cartId}','{$address}','{$billingAddress['address']}','{$billingAddress['city']}','{$billingAddress['state']}','{$billingAddress['country']}','{$billingAddress['zipCode']}')";
            $cartAddress->save($query);
            if ($saveAddress) {
                $query = "INSERT INTO `customer_address`(`customerId`, `address`, `city`, `state`, `zipcode`, `country`, `addressType`) VALUES ('{$customerId}','{$billingAddress['address']}','{$billingAddress['city']}','{$billingAddress['state']}','{$billingAddress['zipCode']}','{$billingAddress['country']}','{$address}')";
                $customerAddress->save($query);
            }
        }
        if ($billingAddress) {
            $query = "UPDATE `cartaddress` SET `city`='{$billingAddress['city']}',`state`='{$billingAddress['state']}',`country`='{$billingAddress['country']}',`zipCode`={$billingAddress['zipCode']} WHERE `cartId`={$cartId}";
            $cartAddress->save($query);
            $query = "UPDATE `customer_address` SET `address`='{$billingAddress['address']}',`city`='{$billingAddress['city']}',`state`='{$billingAddress['state']}',`zipcode`='{$billingAddress['zipCode']}',`country`='{$billingAddress['country']}' WHERE `customerId` = '{$customerId}' AND `addressType`='{$address}'";
            $customerAddress->save($query);
            $customer = \Mage::getModel('Model\Customer');
            $query = "UPDATE `customer` SET `firstName`='{$billingAddress['firstName']}',`lastName`='{$billingAddress['lastName']}',`email`='{$billingAddress['email']}',`phone`='{$billingAddress['phone']}' WHERE `customerId` = '{$customerId}'";
            $customer->save($query);
        }
        $this->redirect('grid');
    }

    public function shipmentAddressAction()
    {
        $address = \Model\Customer\Address::ADDRESS_TYPE_SHIPPING;
        $customerShippingAddress = $this->getCart()->getCustomer()->getCustomerShippingAddress();
        $saveAddress = $this->getRequest()->getPost('saveAddress');
        $customerId = $this->getCart()->customerId;
        $customerAddress = \Mage::getModel('Model\Customer\Address');
        $cartAddress = \Mage::getModel('Model\Cart\Address');
        $cartId = $this->getCart()->cartId;
        $shippingAddress = $this->getRequest()->getPost('shipping');
        if (!$customerShippingAddress) {
            $query = "INSERT INTO `cartaddress`(`cartId`,`addressType`, `address`, `city`, `state`, `country`, `zipCode`) VALUES ('{$cartId}','{$address}','{$shippingAddress['address']}','{$shippingAddress['city']}','{$shippingAddress['state']}','{$shippingAddress['country']}','{$shippingAddress['zipCode']}')";
            $cartAddress->save($query);
            if ($saveAddress) {
                $query = "INSERT INTO `customer_address`(`customerId`, `address`, `city`, `state`, `zipcode`, `country`, `addressType`) VALUES ('{$customerId}','{$shippingAddress['address']}','{$shippingAddress['city']}','{$shippingAddress['state']}','{$shippingAddress['zipCode']}','{$shippingAddress['country']}','{$address}')";
                $customerAddress->save($query);
            }
        }
        if ($shippingAddress) {
            $query = "UPDATE `cartaddress` SET `city`='{$shippingAddress['city']}',`state`='{$shippingAddress['state']}',`country`='{$shippingAddress['country']}',`zipCode`={$shippingAddress['zipCode']} WHERE `cartId`={$cartId}";
            $cartAddress->save($query);
            $query = "UPDATE `customer_address` SET `address`='{$shippingAddress['address']}',`city`='{$shippingAddress['city']}',`state`='{$shippingAddress['state']}',`zipcode`='{$shippingAddress['zipCode']}',`country`='{$shippingAddress['country']}' WHERE `customerId` = '{$customerId}' AND `addressType`='{$address}'";
            $customerAddress->save($query);
            $customer = \Mage::getModel('Model\Customer');
            $query = "UPDATE `customer` SET `firstName`='{$shippingAddress['firstName']}',`lastName`='{$shippingAddress['lastName']}',`email`='{$shippingAddress['email']}',`phone`='{$shippingAddress['phone']}' WHERE `customerId` = '{$customerId}'";
            $customer->save($query);
        }
        $this->redirect('grid');
    }

    public function paymentAction()
    {
        $cart = \Mage::getModel('Model\Cart');
        $customerId = $this->getCart()->customerId;
        $paymentMethod = $this->getRequest()->getPost('payment');
        if ($paymentMethod) {
            switch ($paymentMethod) {
                case 'COD':
                    $cart->paymentMethodId = \Model\Cart::COD;
                    break;
                case 'BHIM UPI':
                    $cart->paymentMethodId = \Model\Cart::BHIM_UPI;
                    break;
                case 'Credit Card':
                    $cart->paymentMethodId = \Model\Cart::CREDITCARD;
                    break;
                case 'Debit Card':
                    $cart->paymentMethodId = \Model\Cart::DEBITCARD;
                    break;
                case 'Net Banking':
                    $cart->paymentMethodId = \Model\Cart::NET_BANKING;
                    break;

                default:
                    throw new \Exception('Invalid Input for payment method.');
                    break;
            }
            $query = "UPDATE `cart` SET `paymentMethodId`='{$cart->paymentMethodId}' WHERE `customerId` = '{$customerId}';";
            $cart->save($query);
            $this->getMessage()->setSuccess('Payment Method successfully slected.');
        }
        $this->redirect('grid');
    }

    public function shipmentAction()
    {
        $cart = \Mage::getModel('Model\Cart');
        $customerId = $this->getCart()->customerId;
        $shippingMethod = $this->getRequest()->getPost('shipment');
        if ($shippingMethod) {
            switch ($shippingMethod) {
                case 'Platinum':
                    $cart->shippingMethodId = \Model\Cart::PLATINUM;
                    break;
                case 'Gold':
                    $cart->shippingMethodId = \Model\Cart::GOLD;
                    break;
                case 'Silver':
                    $cart->shippingMethodId = \Model\Cart::SILVER;
                    break;

                default:
                    throw new \Exception('Invalid Input for shipment method.');
                    break;
            }
            $query = "UPDATE `cart` SET `shippingMethodId`='$cart->shippingMethodId'WHERE `customerId` = '{$customerId}'";
            $cart->save($query);
            if ($cart->shippingMethodId) {
                switch ($shippingMethod) {
                    case 'Platinum':
                        $cart->shippingAmount = \Model\Cart::PLATINUM_FEE;
                        break;
                    case 'Gold':
                        $cart->shippingAmount = \Model\Cart::GOLD_FEE;
                        break;
                    case 'Silver':
                        $cart->shippingAmount = \Model\Cart::SILVER_FEE;
                        break;

                    default:
                        throw new \Exception('Invalid Input for shipment method.');

                        break;
                }
                $query = "UPDATE `cart` SET `shippingAmount`='$cart->shippingAmount' WHERE `customerId` = '{$customerId}';";
                $cart->save($query);
                $this->getMessage()->setSuccess('Shipment Method successfully slected.');
            }
        }
        $this->redirect('grid');
    }
}
