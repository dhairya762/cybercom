<?php

namespace Controller\Admin;

class Hello extends \Controller\Core\Admin
{
    public function testAction()
    {
        echo "<pre>";
        $query = "SELECT * FROM `product` WHERE `productId` = 1";
        $products = \Mage::getModel('Model\Product')->fetchRow($query);
        print_r($products->productId);
        die; 
    }
}
