<?php

namespace Model\Cart;

class Item extends \Model\Core\Table
{
    protected $cart = null;
    protected $product = null;

    public function __construct()
    {
        $this->setTableName('cartItem');
        $this->setPrimaryKey('cartItemId');
    }

    public function getCart()
    {
        if (!$this->cartId) {
            return false;
        }
        $cart = \Mage::getModel('Model\Cart')->load($this->cartId);
        $this->setCart($cart);
        return $this->cart;
    }

    public function setCart(\Model\Cart $cart)
    {
        $this->cart = $cart;
        return $this;
    }

    public function getProduct()
    {
        if (!$this->productId) {
            return false;
        }
        $product = \Mage::getModel('Model\Product')->load($this->productId);
        $this->setProduct($product);
        return $this->product;
    }

    public function setProduct(\Model\Product $product)
    {
        $this->product = $product;
        return $this;
    }

    public function getDiscount()
    {
        $product = \Mage::getModel('Model\Product');
        $query = "SELECT * FROM `{$product->getTableName()}` WHERE `productId` = '{$this->productId}'";
        $product = $product->fetchRow($query);
        return ($product->discount * $this->quantity);
    }
    public function getTotalPrice()
    {
        $price = (($this->quantity * $this->price) - $this->getDiscount());
        return $price;
    }

    // public function updateQuantity()
    // {
    //     $product = \Mage::getModel('Model\Product');
    //     $query = "SELECT * FROM `{$product->getTableName()}` WHERE `productId` = '{$this->productId}'";
    //     $product = $product->fetchRow($query);
    //     echo $product->quantity;
    // }

    public function getRowPrice()
    {
        return $this->price * $this->quantity;
    }
}
