<?php //require_once "header.php";
$shipment = $this->getShipment();
$option = $shipment->getStatusOption();
?>

<div class="container">
    <h2 style="text-align:center ;">Shipment Add/Update Form</h2>

        <form method="post" action="<?php echo $this->getUrl('save') ?>">
  
        <div class="row">
            <div class="col-lg-6">

                <label for="name" class="font-weight-bold">Name</label><br>
                <input type="text" class="form-control"  name="shipment[name]" value="<?php echo $shipment->name; ?>">

                <label for="description" class="font-weight-bold">Description</label><br> 
                <textarea class="form-control" id="description" name="shipment[description]" rows="3"
                value="<?php echo $shipment->description; ?>"><?php echo $shipment->description; ?></textarea>

                <label for="amount" class="font-weight-bold">Amount</label><br>
                <input type="text" class="form-control"  name="shipment[amount]" value="<?php echo $shipment->amount;  ?>">
    
            </div>

            <div class="col-lg-6">

                <label for="code" class="font-weight-bold">Code</label><br>
                <input type="text" class="form-control"  name="shipment[code]" value="<?php echo $shipment->code;  ?>">
                
                <label for="status" class="font-weight-bold">Status</label><br>
                <select name="shipment[status]">
                <?php foreach($option as $key=>$value){ ?>
                    <option value="<?php echo $key; ?>" <?php if($shipment->status == $key){echo "selected";} ?> ><?php echo $value; ?></option>
                <?php } ?>
                </select><br><br>
                <button type="submit" class="btn btn-primary" value="submit">Submit</button>


            </div>
        </div>

        </form>
</div>
