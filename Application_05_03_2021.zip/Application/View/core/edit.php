<table>
    <tbody>
        <tr>
            <td><?php echo $this->getTabHtml(); ?></td>

            <td><?php echo $this->getTabContent(); ?></td>
        </tr>
    </tbody>
</table>