<?php
namespace Block\Admin\Layout;

\Mage::loadFileByClassName('Block\Core\Template');
class Left extends \Block\Core\Template
{
    public function __construct()
    {
        $this->setTemplate('admin/layout/left.php');
    }
}