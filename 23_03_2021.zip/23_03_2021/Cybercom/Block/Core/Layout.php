<?php

namespace Block\Core;


\Mage::loadFileByClassName('Block\Core\Template');

class Layout extends \Block\Core\Template{
    public $children = [];

    public function __construct(\Controller\Core\Admin $controller = null) {
        $this->setTemplate('core/layout/oneColumn.php');
        $this->prepareChildren();
    }

    public function prepareChildren(){
        $this->addChild(\Mage::getBlock("Block\Core\Layout\Header"),'header');
        $this->addChild(\Mage::getBlock('Block\Core\Layout\Left'),'left');
        $this->addChild(\Mage::getBlock('Block\Core\Layout\Content'),'content');
        $this->addChild(\Mage::getBlock('Block\Core\Layout\Footer'),'footer');
    }

}

?>