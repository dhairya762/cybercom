<?php

namespace Block\Admin\CustomerGroup\Edit;

\Mage::getController('Block\Core\Edit\Tabs');

class Tabs extends \Block\Core\Edit\Tabs{

    protected $tabs = [];
    protected $defaultTab = null;

    public function __construct(){
        parent::__construct();
        $this->prepareTab();
    }

    public function prepareTab(){
        if ($this->getRequest()->getGet('id')) {
            $this->addTab('customerGroup',['label'=>'Customer Group','block'=>'Block\Admin\CustomerGroup\Edit\Tabs\Form']);
        }
        $this->setDefaultTab('customerGroup');
        return $this;
   }
}

?>