<?php
namespace Block\Admin\Attribute\Edit\Tabs;

\Mage::loadFileByClassName('Block\Core\Edit');

class AttributeOption extends \Block\Core\Edit
{
    protected $attributeOptions = null;

    public function __construct()
    {
        $this->setTemplate('admin/attribute/edit/tabs/attributeOption.php');
    }

    public function getAttributeOptions()
    {
        if (!$this->attributeOptions) {
            $this->setAttributeOptions();
        }
        return $this->attributeOptions;
    }

    public function setAttributeOptions()
    {
        $attributeOptionRows = \Mage::getModel("Model\Attribute\AttributeOptions");
        if ($id = $this->getTableRow()->attributeId) {
            $query = "SELECT *
                        FROM `{$attributeOptionRows->getTableName()}`
                        WHERE `attributeId` = $id
                    ";
            $row = $attributeOptionRows->fetchAll($query);
            $this->attributeOptions = $row;
        } else {
            $this->attributeOptions = $attributeOptionRows;
        }
    }
}