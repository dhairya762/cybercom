<?php

namespace Block\Admin\Cms\Edit\Tabs;
\Mage::loadFileByClassName('Block\Core\Template');

class Form extends \Block\Core\Template {

    protected $cmsPage = null;

    public function __construct() {
        parent::__construct();
        $this->setTemplate('admin/cms/edit/tabs/form.php');
    }
    
    public function getFormUrl()
    {
        return $this->getUrl()->getUrl('save');
    }
    public function getTitle()
    {
        $id = $this->getRequest()->getGet('id');
        if($id)
        {
            return "CMS Page Edit";
        }
        return 'CMS Page Add';
    }

}

?>