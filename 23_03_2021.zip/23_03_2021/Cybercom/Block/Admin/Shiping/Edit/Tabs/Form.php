<?php

namespace Block\Admin\Shiping\Edit\Tabs;

\Mage::loadFileByClassName('Block\Core\Template');

class Form extends \Block\Core\Template{
    protected $shipment = null;

    public function __construct ()
    {
       parent :: __construct();
       $this->setTemplate('admin/shiping/edit/tabs/form.php');
    }
	
	public function getFormUrl()
    {
        return $this->getUrl()->getUrl('save');
    }
    public function getTitle()
    {
        $id = $this->getRequest()->getGet('id');
        if ($id) {
            return "Shiping Edit";
        }
        return 'Shiping Add';
    }
   }
