<?php

namespace Block\Admin\Shiping\Edit;

\Mage::getController('Block\Core\Edit\Tabs');

class Tabs extends \Block\Core\Edit\Tabs
{

    protected $tabs = [];
    protected $defaultTab = null;

    public function __construct()
    {
        parent::__construct();
        $this->prepareTab();
    }

    public function prepareTab()
    {
        $this->addTab('shiping', ['label' => 'Shipment Form', 'block' => 'Block\Admin\Shiping\Edit\Tabs\Form']);
        $this->setDefaultTab('shiping');
        return $this;
    }
}
