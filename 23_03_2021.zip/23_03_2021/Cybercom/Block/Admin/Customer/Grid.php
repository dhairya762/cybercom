<?php
namespace Block\Admin\Customer;

\Mage::loadFileByClassName('Block\Core\Grid');
/**
 *
 */
class Grid extends \Block\Core\Grid
{
    public function __construct()
    {
        parent::__construct();
        $this->prepareStatus();
    }

    
    public function prepareCollection()
    {
        $customer = \Mage::getModel('Model\Customer');
        $query = "SELECT
							c.`customerId`,
							c.`firstName`,
							c.`lastName`,
							c.`email`,
							c.`mobile`,
							c.`password`,
							c.`status`,
							cg.`name`
						FROM `customer` AS c , `customer_group` AS cg
						WHERE c.`groupId` = cg.`groupId`";
        $rows = $customer->fetchAll($query);
        $this->setCollection($rows);
        return $this;

    }
    public function getTitle()
    {
        return "Customer";
    }
    public function prepareColumns()
    {
        $this->addColumn('customerId', [
            'field' => 'customerId',
            'label' => '#',
            'type' => 'int',
        ]);
        $this->addColumn('firstName', [
            'field' => 'firstName',
            'label' => 'First Name',
            'type' => 'varchar',
        ]);
        $this->addColumn('lastName', [
            'field' => 'lastName',
            'label' => 'Last Name',
            'type' => 'varchar',
        ]);
        $this->addColumn('customerType', [
            'field' => 'name',
            'label' => 'Customer Type',
            'type' => 'varchar',
        ]);
        $this->addColumn('email', [
            'field' => 'email',
            'label' => 'Email',
            'type' => 'varchar',
        ]);
        $this->addColumn('mobile', [
            'field' => 'mobile',
            'label' => 'Mobile No.',
            'type' => 'int',
        ]);

    }
    public function prepareAction()
    {
        $this->addAction('edit', [
            'method' => 'getEditUrl',
            'label' => 'Edit',
            'ajax' => true,
            'class' => 'btn btn-warning',
        ]);
        $this->addAction('delete', [
            'method' => 'getDeleteUrl',
            'label' => 'Delete',
            'ajax' => true,
            'class' => 'btn btn-danger',
        ]);
    }

    public function prepareButton()
    {
        $this->addButton('insert', [
            'method' => 'getInsertUrl',
            'label' => 'Add Customer',
            'ajax' => true,
            'class' => 'btn btn-primary',
        ]);
    }

    public function getInsertUrl($ajax)
    {
        if (!$ajax) {
            return "{$this->getUrl()->getUrl('edit', 'Customer', [], true)}";
        }
        return "object.setUrl('{$this->getUrl()->getUrl('form', 'Customer', [], true)}').resetParams().load()";
    }

    public function getStatusUrl($row, $ajax)
    {
        if (!$ajax) {
            return "{$this->getUrl()->getUrl('status', 'Customer', ['id' => $row->customerId])}";
        }
        return "object.setUrl('{$this->getUrl()->getUrl('status', 'Customer', ['id' => $row->customerId])}').resetParams().load()";
    }
    public function getEditUrl($row, $ajax)
    {
        if (!$ajax) {
            return "{$this->getUrl()->getUrl('edit', 'Customer', ['id' => $row->customerId])}";
        }
        return "object.setUrl('{$this->getUrl()->getUrl('form', 'Customer', ['id' => $row->customerId])}').resetParams().load()";
    }

    public function getDeleteUrl($row, $ajax)
    {
        if (!$ajax) {
            return "{$this->getUrl()->getUrl('delete', 'Customer', ['id' => $row->customerId])}";
        }
        return "object.setUrl('{$this->getUrl()->getUrl('delete', 'Customer', ['id' => $row->customerId])}').resetParams().load()";
    }

}