<?php
namespace Block\Admin\Customer\Edit\Tabs;

\Mage::loadFileByClassName('Block\Core\Edit');
/**
 *
 */
class Form extends \Block\Core\Edit
{
    protected $customerGroup;

    public function __construct()
    {
        parent::__construct();
        $this->setTemplate('admin/customer/edit/tabs/form.php');
    }

    protected function setCustomerGroup($customerGroup = null)
    {
        if ($this->customerGroup) {
            $this->customerGroup = $customerGroup;
        }
        $customerGroup = \Mage::getModel('Model\Customer\CustomerGroup');
        $row = $customerGroup->fetchfetchAll;
        $this->customerGroup = $row;
        return $this;
    }
    public function getcustomerGroup()
    {
        if (!$this->customerGroup) {
            $this->setCustomerGroup();
        }
        return $this->customerGroup;
    }
}