<?php
namespace Model\Brand;

\Mage::loadFileByClassName('Model\Core\Collection');
/**
 *
 */
class Collection extends \Model\Core\Collection
{

}