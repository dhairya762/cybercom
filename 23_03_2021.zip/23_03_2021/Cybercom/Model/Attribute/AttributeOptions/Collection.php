<?php
namespace Model\Attribute\AttributeOptions;

\Mage::loadFileByClassName('Model\Core\Collection');
class Collection extends \Model\Core\Collection
{

}