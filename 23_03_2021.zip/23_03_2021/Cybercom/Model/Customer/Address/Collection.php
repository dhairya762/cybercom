<?php
namespace Model\Customer\Address;

\Mage::loadFileByClassName('Model\Core\Collection');
/**
 *
 */
class Collection extends \Model\Core\Collection
{

}