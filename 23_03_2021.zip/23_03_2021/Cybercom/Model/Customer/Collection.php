<?php
namespace Model\Customer;

\Mage::loadFileByClassName('Model\Core\Collection');

/**
 *
 */
class Collection extends \Model\Core\Collection
{

}