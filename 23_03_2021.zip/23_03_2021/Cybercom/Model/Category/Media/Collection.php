<?php
namespace Model\Category\Media;

\Mage::loadFileByClassName('Model\Core\Collection');
/**
 *
 */
class Collection extends \Model\Core\Collection
{

}