<?php
namespace Model\Category;
\Mage::loadFileByClassName('Model\Core\Collection');
/**
 * 
 */
class Collection  extends \Model\Core\Collection
{
	
}
?>