<footer class="bg-light text-center text-lg-start">
		 	<div class="text-center p-3" style="background-color: rgba(0, 0, 0, 0.2)">
                     <p><strong>Smile</strong> is the best medicine for all the <strong>situations</strong>.</p>
			</div>
		</footer>
<script type="text/javascript" src="js/bootstrap.bundle.min.js"></script>
<script type="text/javascript" src="js/bootstrap.js"></script>