<?php echo $this->getChild('header')->toHtml(); ?>
<?php if ($this->getChild('message')) : ?>
    <?= $this->getChild('message')->toHtml(); ?>
<?php endif; ?>
<?php echo $this->getChild('content')->toHtml(); ?>
<?php echo $this->getChild('footer')->toHtml(); ?>