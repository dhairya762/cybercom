<nav class="navbar navbar-expand-sm bg-info sticky-top">
       <!-- <div class="footer"> -->
              <h1><p><strong>Smile</strong> is the best medicine for all the <strong>situations</strong>.</p></h1>
       <!-- </div> -->
</nav>