<?php
namespace Controller\Admin;
\Mage::loadFileByClassName('Controller\Core\Admin');

class Shipment extends \Controller\Core\Admin{
    protected $shipments = [];

    public function gridAction (){
       
        try{
            $gridBlock = \Mage::getBlock('Block\Admin\Shipment\Grid');
            $gridBlock->setController($this);
            $layout = $this->getLayout();
            $content = $layout->getChild('content');
            $content->addChild($gridBlock);
            $this->toHtmlLayout();

        }catch(\Exception $e){
            echo $e->getMessage();
        }
    }
    

    
    public function saveAction(){

        try{
            $shipment = \Mage::getModel('Model\Shipment');

            if(!$this->getRequest()->isPost()){
                throw new \Exception ("Invalid Request");
            }
            if ($id = $this->getRequest()->getGet('id')) {
                $shipment = $shipment->load($id);
                if (!$shipment){
                    throw new \Exception ("Records not found.");
                }
            }
            else {
                $shipment->createdDate = date("Y-m-d H:i:s");
            }
            $shipmentData = $this->getRequest()->getPost('shipment'); 
            $shipment->setData($shipmentData);
            $shipment->save();
            $this->getMessage()->setSuccess('Record Inserted Successfully.');    
        }
        catch(\Exception $e){
            $this->getMessage()->setFailure($e->getMessage());
            //echo $e->getMessage();
        }
        $this->redirect("grid",null,null,true);
    }
       
    public function shipmentUpdateAction()
    {
        try{
            $gridBlock = \Mage::getBlock('Block\Admin\Shipment\Edit');
            $gridBlock->setController($this);
            $layout = $this->getLayout();
            $layout->setTemplate('./View/core/layout/three_column.php');
            $content = $layout->getChild('content');
            $content->addChild($gridBlock);
            $this->toHtmlLayout();

        
        }catch(\Exception $e){
            echo $e->getMessage();
        }
        
        
    }
    
    
    public function shipmentDeleteAction()
    {
        try{
            $id = $this->getRequest()->getGet('id');
            if(!$id){
                throw new \Exception("Invalid ID.");    
            }
            $shipment = \Mage::getModel('Model\Shipment');
            //$shipment = $this->getshipment();
            $shipment->load($id);
            if($shipment->delete()) {
                $this->getMessage()->setSuccess('Record Deleted Successfully.');
            }
            else {
                $this->getMessage()->setFailure('Unable to Delete Record.');
            }
        }
        catch (\Exception $e) {
            $this->getMessage()->setFailure($e->getMessage());
        }  
        $this->redirect("grid",null,null,true);
    }
    
}


?>


