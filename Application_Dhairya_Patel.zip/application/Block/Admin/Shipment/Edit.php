<?php
namespace Block\Admin\Shipment;
\Mage::loadFileByClassName('Block\Core\Template');

class Edit extends \Block\Core\Template
{
    protected $shipment = NULL;

    public function __construct() {
        $this->setTemplate('./View/admin/shipment/edit.php');
    }

    public function setShipment($shipment = NULL){
        if (!$shipment){
            $shipment = \Mage::getModel('Model\Shipment');
            if($id = $this->getRequest()->getGet('id')){
                $shipment = $shipment->load($id);
            }
        }
        $this->shipment = $shipment;
        return $this;
    }
    
    public function getShipment(){
        if (!$this->shipment){
            $this->setshipment();
        }
        return $this->shipment;
    }

    
}




?>